//Faris Ikhlasul Haq
//TI-2A
<html>
    <head></head>
    <body>
        Terima Kasih  <?php echo $_POST["username"];?> !! <br>
        Id Anda Adalah : <?php echo $_POST["id"];?> <br>
		Anda Termasuk : <?php echo $_POST["var3"];?> <br>
		Makanan Yang Anda Pesan : <?php echo $_POST["mak1"];?><br>
		 						  <?php	echo $_POST["mak2"];?><br>
		 						  <?php	echo $_POST["mak3"];?><br>
								  <?php	echo $_POST["mak4"];?>
    </body>
</html>