<?php
    include "koneksi.php";

        $username = $_POST['username'];
        $password = $_POST['password'];

        $query="SELECT * FROM user WHERE username='$username' AND 
        password ='$password'";
        $result = mysqli_query($connect, $query);
        $cektest = mysqli_num_rows($result);

        if($cektest){
            echo "Anda Berhasil Login. Silahkan menuju "; ?>
            <a href="Home.html">Halaman Home</a>
        <?php
        }else{
            echo "Anda gagal login. Silahkan "?>
            <a href="LoginUserIndex.php">Login Kembali</a>
            <?php
            echo mysqli_error($connect);
        }

	mysqli_close($connect);
?>