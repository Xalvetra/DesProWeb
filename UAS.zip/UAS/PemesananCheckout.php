<html>
    <title>CheckOut</title>
    <head>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    </head>
    <body>
<div class="container wrapper">
            <div class="row cart-head">
                <div class="container">
                <div class="row">
                    <p></p>
                </div>
                
                <div class="row">
                    <div style="display: table; margin: auto;">
                        <span class="step step_complete"> <a href="Home.php" class="check-bc">Home</a> <span class="step_line step_complete"> </span> <span class="step_line backline"> </span> </span>
                        <span class="step step_complete"> <a href="Pemesanan.php" class="check-bc">Pemesanan</a> <span class="step_line "> </span> <span class="step_line step_complete"> </span> </span>
                    </div>
                </div>
            </div>    
            <div class="row cart-body">
                <form class="form-horizontal" method="post" action="">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-push-6 col-sm-push-6">
                <div class="panel panel-info">
                        <div class="panel-heading">Alamat Titik</div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <h4>Alamat Diisi Sesuai Tempat Anda Sekarang</h4>
                                </div>
                            </div>
                          <div class="form-group">
                                <div class="col-md-12"><strong>Provinsi</strong></div>
                                <div class="col-md-12">
                                    <select id="provinsi" name="provinsi" class="form-control">
                                        <option value="5">Jawa Timur</option>
                                        <option value="6">Jawa Tengah</option>
                                        <option value="7">Jawa Barat</option>
                                        <option value="8">Bali</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>Alamat :</strong></div>
                                <div class="col-md-12"><input type="text" class="form-control" name="alamat" value="" /></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-6">
                                    <strong>Kota</strong>
                                </div>
                                <div class="col-md-6">
                                    <strong>&nbsp;&nbsp;&nbsp;&nbsp;Kode Pos</strong>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" name="kota">
                                        <option value="">Kota</option>
                                        <option value="01">Malang</option>
                                        <option value="02">Surabaya</option>
                                        <option value="03">Kediri</option>
                                        <option value="04">Kudus</option>
                                        <option value="05">Solo</option>
                                        <option value="06">Semarang</option>
                                        <option value="07">Bandung</option>
                                        <option value="08">Purwakarta</option>
                                        <option value="09">Depok</option>
                                        <option value="10">Bogor</option>
                                        <option value="11">Denpasar</option>
                                        <option value="12">Gianyar</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="col-md-12"><input type="text" class="form-control" name="kodepos" value="" placeholder="kode pos" /></div>
                                </div>
                            </div>
                            <div class="form-group">
                            </div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <button type="submit" class="btn btn-primary btn-submit-fix"> ~ Booking ~</button>
                                </div>
                            </div>
                         </div>
                         </div>
                         </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-pull-6 col-sm-pull-6">
                    <!--SHIPPING METHOD-->
                    <div class="panel panel-info">
                        <div class="panel-heading">DATA DIRI</div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <h4<b>NB: DIIISI SESUAI DENGAN ANDA</b></h4>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>No ID</strong></div>
                                <div class="col-md-12">
                                    <input type="text" class="form-control" name="noid" value="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12 col-xs-12">
                                    <strong>Nama</strong>
                                    <input type="text" name="first_name" class="form-control" value="" />
                                </div>
                                <!-- <div class="span1"></div>
                                <div class="col-md-6 col-xs-12">
                                    <strong>Last Name:</strong>
                                    <input type="text" name="last_name" class="form-control" value="" />
                                </div> -->
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>Umur </strong></div>
                                <div class="col-md-12">
                                    <input type="text" name="umur" class="form-control" value="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>Tanggal Lahir </strong></div>
                                <div class="col-md-12">
                                    <input type="text" name="ttl" class="form-control" value="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>No Telepon </strong></div>
                                <div class="col-md-12">
                                    <input type="text" name="notelp" class="form-control" value="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12"><strong>Email Anda </strong></div>
                                <div class="col-md-12"><input type="text" name="email" class="form-control" value="" /></div>
                            </div>
                            
                            <div class="form-group">
                            <div class="col-md-6">
                                    <strong>Pengambilan Sampah</strong>
                                </div>
                                <div class="col-md-6">
                                    <strong>Agen Kebersihan</strong>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" name="pengambilansampah">
                                        <option value="">Pilih 1</option>
                                        <option value="01">1x Pengambilan</option>
                                        <option value="02">2x Pengambilan</option>
                                        <option value="03">3x Pengambilan</option>
                                    </select>
                                </div>
                                
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" name="agenkebersiham">
                                        <option value="">Pilih 1</option>
                                        <option value="04">2 in 1</option>
                                        <option value="05">3 in 1</option>
                                        <option value="06">4 in 1</option>
                                    </select>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    <!--SHIPPING METHOD END-->
                </form>
            </div>
            <div class="row cart-footer">
            </div>
    </div>
    </body>
</html>